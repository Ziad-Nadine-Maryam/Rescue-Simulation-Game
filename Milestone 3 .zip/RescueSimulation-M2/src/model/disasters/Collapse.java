package model.disasters;

import exceptions.BuildingAlreadyCollapsedException;
import exceptions.SimulationException;
import model.infrastructure.ResidentialBuilding;


public class Collapse extends Disaster {

	public Collapse(int startCycle, ResidentialBuilding target) {
		super(startCycle, target);
		
	}
	public void strike() throws SimulationException
	{  ResidentialBuilding target= (ResidentialBuilding)getTarget();	
		
		if(target.getStructuralIntegrity()==0){
			BuildingAlreadyCollapsedException e = new BuildingAlreadyCollapsedException(this , "This Building has already collapsed") ;
			throw e ; 
			}
		else{
			target.setFoundationDamage(target.getFoundationDamage()+10) ;
			super.strike();
		}
			
		}
		
	
	public String toString(){
		if(this.isActive()){
		String s = "Collapse";
		return s;
		}
		else
			return "No Disaster";
	}
	public void cycleStep()
	{
		ResidentialBuilding target= (ResidentialBuilding)getTarget();
		target.setFoundationDamage(target.getFoundationDamage()+10);
	}

}

package model.disasters;

import exceptions.BuildingAlreadyCollapsedException;
import exceptions.SimulationException;
import model.infrastructure.ResidentialBuilding;


public class Fire extends Disaster {

	public Fire(int startCycle, ResidentialBuilding target) {
		super(startCycle, target);
		
	}
	@Override
	public void strike() throws SimulationException
	{
		ResidentialBuilding target= (ResidentialBuilding)getTarget();
		
			if(target.getStructuralIntegrity()==0){
				BuildingAlreadyCollapsedException e = new BuildingAlreadyCollapsedException(this , "This Building has already collapsed") ;
				throw e ;
			}else{
				target.setFireDamage(target.getFireDamage()+10);
			super.strike();
			
				
		} 
		
		
		
		
		
	}	
	public String toString(){
		if(this.isActive()){
		String s = "Fire";
		return s;
		}
		else
			return "No Disaster";
	}
	
	@Override
	public void cycleStep() {
		ResidentialBuilding target= (ResidentialBuilding)getTarget();
		target.setFireDamage(target.getFireDamage()+10);
		
	}

}

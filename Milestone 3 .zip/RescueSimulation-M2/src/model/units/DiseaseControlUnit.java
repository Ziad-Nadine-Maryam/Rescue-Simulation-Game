package model.units;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import exceptions.SimulationException;
import model.disasters.*;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import simulation.Address;
import simulation.Rescuable;

public class DiseaseControlUnit extends MedicalUnit {

	public DiseaseControlUnit(String unitID, Address location,
			int stepsPerCycle, WorldListener worldListener) {
		super(unitID, location, stepsPerCycle, worldListener);
	}

	@Override
	public void treat() {
		getTarget().setUnit(this);
		getTarget().getDisaster().setActive(false);
		Citizen target = (Citizen) getTarget();
		if (target.getHp() == 0) {
			jobsDone();
			return;
		} else if (target.getToxicity() > 0) {
			target.setToxicity(target.getToxicity() - getTreatmentAmount());
			if (target.getToxicity() == 0)
				target.setState(CitizenState.RESCUED);
		}

		else if (target.getToxicity() == 0)
			heal();

	}

	public void respond(Rescuable r) throws SimulationException  {
		if (r instanceof ResidentialBuilding){
			IncompatibleTargetException e = new IncompatibleTargetException(this, r,"This Unit only responds to Citizens");
			throw e ;
			
		}
		if(!(canTreat(r))){
			CannotTreatException e = new CannotTreatException(this, r,"This Citizen cannot be treated by this unit");
			throw e ;
		}else{
		if (getTarget() != null && ((Citizen) getTarget()).getToxicity() > 0
				&& getState() == UnitState.TREATING)
			reactivateDisaster();
		finishRespond(r);
	}}
	public boolean canTreat(Rescuable r){
		if(r.getDisaster() instanceof Infection && ((Citizen)r).getState()!=CitizenState.SAFE)
			
			return true ;
		else 
			return false ;

	}
	public String toString(){
		String s = "Disease Control unit"+"\n"+super.toString();
		return s;
	}



}

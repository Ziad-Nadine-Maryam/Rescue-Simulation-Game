package model.units;
import simulation.*;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import simulation.Address;
import model.people.*;
public class Evacuator extends PoliceUnit {

	public Evacuator(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener, int maxCapacity) {
		super(unitID, location, stepsPerCycle, worldListener, maxCapacity);

	}

	@Override
	public void treat() {
		getTarget().setUnit(this);
		ResidentialBuilding target = (ResidentialBuilding) getTarget();
		if (target.getStructuralIntegrity() == 0
				|| target.getOccupants().size() == 0) {
			jobsDone();
			return;
		}

		for (int i = 0; getPassengers().size() != getMaxCapacity()
				&& i < target.getOccupants().size(); i++) {
			getPassengers().add(target.getOccupants().remove(i));
			i--;
		}

		setDistanceToBase(target.getLocation().getX()
				+ target.getLocation().getY());

	}
	
	public String toString(){
		String s = "Evacuator"+"\n"+super.toString()+"\n"+printPassengers();
		return s;
	}
	public String printPassengers(){
		String s = "Number of passengers: " + this.getPassengers().size();
		for(int i=0;i<this.getPassengers().size();i++){
			s+=getPassengers().get(i).toString();
		}
		return s;
	}


}


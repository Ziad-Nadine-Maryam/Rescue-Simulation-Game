package model.units;

import exceptions.* ;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Address;
import simulation.Rescuable;


public abstract class FireUnit extends Unit {

	public FireUnit(String unitID, Address location, int stepsPerCycle,WorldListener worldListener) {
		super(unitID, location, stepsPerCycle,worldListener);
	}
	public void respond(Rescuable r) throws SimulationException {
		
			if(r instanceof Citizen) {
				IncompatibleTargetException e = new IncompatibleTargetException(this,r,"this unit only responds to buildings") ;
				throw e ; 
			}
			else{
				if(!canTreat(r)){
					CannotTreatException e = new CannotTreatException(this, r,"this building cannot be treatd by this unit") ;
					throw e ;
				}else
					super.respond(r);
			}

		
	}


}

package controller;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import exceptions.SimulationException;
import view.*;

import java.util.ArrayList;

import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;
import simulation.Rescuable;
import simulation.Simulatable;
import simulation.Simulator;
import view.GameView;
import view.MapButton;
import view.UnitButton;



public class CommandCenter implements SOSListener,ActionListener {

	private Simulator engine;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
	private ArrayList<Unit> emergencyUnits;
	private GameView gameview;
	private UnitButton selection;
	private MapButton temp;

	public CommandCenter() throws Exception {
		engine = new Simulator(this);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		emergencyUnits = engine.getEmergencyUnits();
		gameview = new GameView();
		engine.setGameView(gameview);

		//--------------------------------------------------------------
		JButton nb = gameview.getNextCycle();
		nb.addActionListener(this) ;
        loadMyGame();
		arrangeUnits();
	//	gameview.x[1][7].setBackground(Color.GRAY);
		gameview.validate();
	}

	@Override
	public void receiveSOSCall(Rescuable r) {

		if (r instanceof ResidentialBuilding) {

			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);

		} else {

			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}
		
		GameView.addObject((Simulatable) r);
		

	}


	public void arrangeUnits()
	{
		gameview.getIdlePanel().removeAll();
		gameview.getRespondingPanel().removeAll();
		gameview.getTreatingPanel().removeAll(); 


		for (int i = 0; i < emergencyUnits.size(); i++) {
			Unit u = emergencyUnits.get(i);
			UnitButton btn = new UnitButton((gameview.getStatusPanel()),u);
			
			btn.addActionListener(this); 
		   ///btn.setText(emergencyUnits.get(i).getClass().getSimpleName());
			if(u instanceof Ambulance) {
				btn.setIcon(new ImageIcon("amb.png"));
			}else if (u instanceof DiseaseControlUnit) {
				btn.setIcon(new ImageIcon("diseasephoto.png"));
			}else if(u instanceof FireTruck) {
				btn.setIcon(new ImageIcon("fire.png"));
			}else if(u instanceof Evacuator) {
				btn.setIcon(new ImageIcon("evc.png"));
			}else if (u instanceof GasControlUnit) {
				btn.setIcon(new ImageIcon("kiki.png"));
			}
			
			btn.setPreferredSize(new Dimension(70,65));
			gameview.getPanel(btn).add(btn);
			
			
			
		}
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				for (int s = 0; s <gameview.x[i][j].getAbc().size() ; s++) {
					Simulatable hamada = gameview.x[i][j].getAbc().get(s) ;
					if(hamada instanceof Unit) {
						gameview.x[i][j].getAbc().remove(s) ;
						
					}
					
				}
				
		
				
			}
			
		}
		
		for(Unit u : emergencyUnits) {
			int a=u.getLocation().getX() ;
			int b = u.getLocation().getY() ;
			
			gameview.x[b][a].addObject(u);
		}
			
		

		gameview.revalidate();
		gameview.repaint();
	}

	
	public void loadMyGame() {
		
		MapButton[][] city = gameview.getMapButtons();
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				temp = city[i][j];
			
				temp.addActionListener(this); 
			}
		}
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource() instanceof MapButton){
			
			if(selection!=null){
				MapButton t = (MapButton)arg0.getSource();
				Rescuable target = t.getTarget();
				if(target!=null){
					try{
						selection.getUnit().respond(target);
						selection=null;
					}
					catch(SimulationException e){
						JOptionPane.showMessageDialog(gameview, e.getMessage());
					}
				}
			}
		}
		
		
		else{
			if(arg0.getSource() instanceof UnitButton){
				gameview.getStatusPanel().setText(((UnitButton)arg0.getSource()).toString());
				selection=(UnitButton)arg0.getSource();
				
			}
			else
				if(!engine.checkGameOver()){
					try {
						arrangeUnits();
						graphics() ;
						engine.nextCycle();
						
					} catch (SimulationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else
					if(engine.checkGameOver()){
						int x = engine.calculateCasualties() ;
						String y = "Casualties:" + x ;
						String z= "GAME OVER!" + "\n" + y ;
						JOptionPane.showMessageDialog(gameview,z);
					}
		
	}


	}
	private void graphics() {
	   for(ResidentialBuilding building : visibleBuildings ) {
		   int a = building.getLocation().getX() ;
		   int b = building.getLocation().getY() ;
		   if(building.getDisaster().isActive()) {
			   Disaster d = building.getDisaster() ;
			   if(d instanceof Fire) {
				   gameview.x[b][a].setIcon(new ImageIcon("firedis.png"));
				   
			   }else if(d instanceof GasLeak) {
				   gameview.x[b][a].setIcon(new ImageIcon("gasdis.png"));
				   
			   }else if(d instanceof Collapse) {
				   gameview.x[b][a].setIcon(new ImageIcon("collapse.png"));
			   }
			   
		   } else{
			   gameview.x[b][a].setIcon(new ImageIcon("building.png"));
		   }
		   
		   
		  
	   }
	   for(Citizen citizen : visibleCitizens ) {
		   int a = citizen.getLocation().getX() ;
		   int b = citizen.getLocation().getY() ; 
		   
		   if(citizen.getHp()==0) {
			   
			      gameview.x[b][a].setIcon(new ImageIcon("dead.png"));
			   }else if(citizen.getHp()>0 &&citizen.getHp()<=30){
				   gameview.x[b][a].setIcon(new ImageIcon("0300.png"));
			   }else if(citizen.getHp()>30 &&citizen.getHp()<=70){
				   gameview.x[b][a].setIcon(new ImageIcon("3070.png"));
				   
			   }else if(citizen.getHp()>70 &&citizen.getHp()<100) {
				   gameview.x[b][a].setIcon(new ImageIcon("70100.png"));
			   }else if(citizen.getHp()==100){
				   gameview.x[b][a].setIcon(new ImageIcon("100.png"));
			   }
			  
		   }
			   
		   
		   
		
	}

	public static void main(String[] args) throws Exception {
		CommandCenter cc = new CommandCenter();
	}

	public ArrayList<Unit> getEmergencyUnits() {
		return emergencyUnits;
	}
public void CCupdater() {
	for(Unit u : emergencyUnits) {
		int a=u.getLocation().getX() ;
		int b = u.getLocation().getY() ;
		gameview.x[b][a].addActionListener(this);
			
	}
		
}
	

}

package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextArea;

import model.units.Unit;
public class UnitButton extends JButton implements ActionListener{
	private Unit unit;
	private JTextArea j;
	
	public UnitButton(JTextArea wareny,Unit u){
		j=wareny;
		unit = u;
		addActionListener(this);
	}
	public void addUnit(Unit unit){
		this.setText(unit.getUnitID());
		
		
	}
	
	public Unit getUnit() {
		return unit;
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		String p = "";
			p+= unit.toString() + "\n\n";
		j.setText(p);
		
	}




}

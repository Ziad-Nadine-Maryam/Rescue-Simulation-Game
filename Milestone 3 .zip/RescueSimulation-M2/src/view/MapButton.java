package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextArea;

import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Rescuable;
import simulation.Simulatable;

public class MapButton extends JButton  implements ActionListener{
	
	private ArrayList<Simulatable> abc;
	private JTextArea status;
	public MapButton(JTextArea status) {
		this.status=status;
		abc = new ArrayList<>();
		addActionListener(this);
	}
	
	public Rescuable getTarget() {
		for (int i = 0; i < abc.size(); i++) {
			if (abc.get(i) instanceof Rescuable) {
				return (Rescuable) abc.get(i);
			}
		}
		return null;
	}

	public void addObject(Simulatable sim) {
		if (!abc.contains(sim)) {
			abc.add(sim);
			if(sim instanceof Citizen) {
				setIcon(new ImageIcon("100.png"));
					
			}else if(sim instanceof ResidentialBuilding)
				setIcon(new ImageIcon("building.png"));
		}
	}
	
	public void removeObject(Simulatable sim) {
		abc.remove(sim);
	}
	
	public void redraw() {
		setBackground(Color.green);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		String text = "";
		for (int i = 0; i < abc.size(); i++) {
			text += abc.get(i).toString() + "\n\n";
		}
		status.setText(text);
	}

	public ArrayList<Simulatable> getAbc() {
		return abc;
	}
		
	
}

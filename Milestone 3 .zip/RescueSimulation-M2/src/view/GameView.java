package view;


import simulation.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.print.attribute.standard.MediaSize.Engineering;
import javax.swing.*;
import javax.swing.border.TitledBorder;

import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.units.Unit;
import model.units.UnitState;
import simulation.Simulator;
import controller.CommandCenter;


public class GameView extends JFrame {

	private JPanel shemal ;
	private JPanel felnos ;
	private JPanel yemen ;
	private JPanel available;
	private JPanel responding;
	private JPanel treating;
	public static MapButton[][] x ;
	private JButton y ;
	private JTextArea status;
	private JTextArea currentCycle;
	private JTextArea casualties;
	private JTextArea infoNow;
	private JTextArea infoAll;
    private JPanel hetaso8aiara ; 
    private JPanel curr;
    private JButton sa3a ; 
    private JButton taboot ; 

	public GameView() {


    generateMyPanel();		
    
	
	}	
	
	public static void addObject(Simulatable object) {
		if (object instanceof Citizen) {
			Citizen c = (Citizen) object;
			x[c.getLocation().getY()][c.getLocation().getX()].addObject(c);
		} else if (object instanceof ResidentialBuilding) {
			ResidentialBuilding rb = (ResidentialBuilding) object;
			x[rb.getLocation().getY()][rb.getLocation().getX()].addObject(rb);
		} else if (object instanceof Unit) {
			Unit u = (Unit) object;
			x[u.getLocation().getY()][u.getLocation().getX()].addObject(u);
		}
	}

	public JButton getNextCycle() {
		return y;
	}
	
	public MapButton[][] getMapButtons() {
		return x;
	}
	
	public JTextArea getStatusPanel() {
		return status;
	}
	
	
	
	public JPanel getPanel(UnitButton button){
		Unit x = button.getUnit() ;
		UnitState xy = x.getState() ;
		if(xy==UnitState.IDLE){
			return available ;
			//getIdlePanel() ;
		}else if(xy==UnitState.RESPONDING){
			return responding ;
			//getRespondingPanel() ;
		}else if(xy==UnitState.TREATING) {
			//getTreatingPanel() ;
			return treating ;
			
		}
		return null ;
		
	}
	
	public JPanel getIdlePanel() {
		return available;
	}
	
	public JPanel getRespondingPanel() {
		return responding;
	}
	
	public JPanel getTreatingPanel() {
		return treating;
		
		
	}
	
	public void setCurrentCycle(int cycle) {
		currentCycle.setText("Current Cycle: " + cycle);
	}
	
	public void setCasualties(int casualtiesAmount) {
		casualties.setText("Casualties: " + casualtiesAmount);
	}
	
	public void updateActiveDisasters(String activeDisasters) {
		infoNow.setText(activeDisasters);
	}
	
	public void updateGameLog(String gameLog) {
		String s = infoAll.getText() + "\n\n" + gameLog;
		infoAll.setText(s.trim());
	}

public void generateMyPanel(){
	setTitle("Rescue Simulation");
	setVisible(true);
	setDefaultCloseOperation(EXIT_ON_CLOSE);	  
	setLayout(new BorderLayout(100, 100));
	setBounds(50, 50, 1200, 600);
	generateLeft() ;
	generateMiddle() ;
	generateRight() ;
	this.add(yemen,BorderLayout.EAST) ;
	this.add(shemal,BorderLayout.WEST) ;
	this.add(felnos,BorderLayout.CENTER) ; 
	loadMyWorld() ;
	loadMyCC() ;
	
	
}





private void generateLeft() {
	shemal = new JPanel() ;
	shemal.setLayout(new GridLayout(4,1));
	TitledBorder b1=new TitledBorder("Available Units");
	TitledBorder b2 = new TitledBorder("Responding Units");
	TitledBorder b3 = new TitledBorder("Treating Units");
	available = new JPanel() ;
	available.setBorder(b1);
	responding = new JPanel() ;
	responding.setBorder(b2);;
	treating = new JPanel() ;
	treating.setBorder(b3);
	treating.setPreferredSize(new Dimension(250,200));
	
	
	available.setLayout(new FlowLayout());
	treating.setLayout(new FlowLayout());
	responding.setLayout(new FlowLayout());
	
	
	
	shemal.add(available);
	shemal.add(responding) ;
	shemal.add(treating) ;
	shemal.add(generatePlayPanel()) ;
	shemal.setPreferredSize(new Dimension(300,200));
	
	
	
	
	
	
}
public JPanel generatePlayPanel() {
	JPanel play = new JPanel() ;
	play.setBackground(Color.red);
	play.setLayout(new GridLayout(3,1));
	play.setPreferredSize(new Dimension(250,200));
	JPanel hetaso8aiara=new JPanel(new GridLayout(1,2));
	JPanel curr = new JPanel(new GridLayout(1,2)) ;
	taboot=new JButton() ; 
	sa3a = new JButton();
	y = new JButton() ;
	y.setText("Next Cycle");
	y.setBackground(Color.white);
	y.setBorder(null);
	y.setIcon(new ImageIcon("nxt.png"));
	validate(); 
taboot.setIcon(new ImageIcon("mat.png"));
taboot.setBackground(Color.white);
sa3a.setIcon(new ImageIcon("1.png"));
sa3a.setBackground(Color.white);
validate(); 
	currentCycle = new JTextArea("Current Cycle: 0") ;
	casualties = new JTextArea("Casualties: 0") ;

	currentCycle.setEditable(false);
	casualties.setEditable(false);

	play.add(curr) ;
	play.add(y) ;
	play.add(hetaso8aiara) ;
	curr.add(sa3a);
	curr.add(currentCycle);
	hetaso8aiara.add(taboot);
	hetaso8aiara.add(casualties);
	sa3a.setBorder(null);
	taboot.setBorder(null);
	return play ;
	
}

private void generateMiddle() {
	felnos = new JPanel() ;
	felnos.setLayout(new GridLayout(10, 10));
	felnos.setBackground(Color.orange);
	felnos.setPreferredSize(new Dimension(1200, 600));
	
	
}

private void generateRight() {
	yemen = new JPanel() ;
	yemen.setLayout(new GridLayout(3,1));
	TitledBorder b6 = new TitledBorder("Info");
	status = new JTextArea() ;
	status.setBorder(b6);
	status.setBackground(Color.LIGHT_GRAY);
	status.setEditable(false);
	TitledBorder b4 = new TitledBorder("Active Disasters");
	infoNow = new JTextArea();
	infoNow.setBorder(b4);
	infoNow.setBackground(Color.LIGHT_GRAY);
	infoNow.setEditable(false);
    TitledBorder b5 = new TitledBorder("Log");
	infoAll = new JTextArea();
	infoAll.setBorder(b5);
	infoAll.setBackground(Color.LIGHT_GRAY);
	infoAll.setEditable(false);
	
	
	JScrollPane scrollPane1 = new JScrollPane(status);
	JScrollPane scrollPane2 = new JScrollPane(infoNow);
	JScrollPane scrollPane3 = new JScrollPane(infoAll);
	scrollPane1.setPreferredSize(new Dimension(250,getHeight()/3));
	scrollPane2.setPreferredSize(new Dimension(250,getHeight()/3));
	scrollPane3.setPreferredSize(new Dimension(250,getHeight()/3));

	yemen.add(scrollPane1);
	yemen.add(scrollPane2);
	yemen.add(scrollPane3);
	
	
	
}
private void loadMyWorld() {
	x = new MapButton[10][10] ;
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			x[i][j] = new MapButton(status) ;	 
			MapButton g = x[i][j] ;
			g.setIcon(new ImageIcon("fififi.png"));
			felnos.add(g) ;

		}
	}
	
	
	
	
}


private void loadMyCC() {
	//x[0][0].setBackground(Color.T);
	//x[0][0].setText("CC");
	x[0][0].setIcon(new ImageIcon("cc.png"));
	
	
	
	validate();
	
	
}
}


